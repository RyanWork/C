/* Functions that model the motion of an object. */
//Models the velocity of the object
double calculate_velocity(double initial_v, double accel, double time);

//Models the displacement of the object
double calculate_displacement(double initial_v, double accel, double time);
