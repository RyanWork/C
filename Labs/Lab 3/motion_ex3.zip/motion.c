/* Functions that model the motion of an object. */
#include <stdio.h>
#include "motion.h"
#include <math.h>

/* Returns the velocity (m/s) of an object with initial velocity
   initial_v (m/s), undergoing constant acceleration accel (m/s^2), 
   after after time seconds.
*/
double calculate_velocity(double initial_v, double accel, double time)
{
	return initial_v + accel * time;
}

double calculate_displacement(double initial_v, double accel, double time)
{
	return (initial_v * time) + (accel/2 * pow(time,2));
}
