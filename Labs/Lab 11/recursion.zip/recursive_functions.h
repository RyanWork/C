/* SYSC 2006 Winter 2015 Lab 11. */

double power(double x, int n);
double power2(double x, int n);
int num_digits(int n);
int occurrences(int a[], int n, int target);
